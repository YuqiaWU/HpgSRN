%% Load data
load('space_ga_expand9.mat');
load('space_ga_scale.mat');

%% Computation of data feature
A = space_ga_expand9;
b = space_ga_scale(:, 1);
[m, n] = size(A);

ATmap = @(x) A'*x;
lambdamax=norm(ATmap(b),'inf');
scale = 0.0001; 
lambda = scale * lambdamax;
q= 1/2;

eigsopt.issym = 1;
Rmap=@(x) A*x;
Rtmap=@(x) A'*x;
RRtmap=@(x) Rmap(Rtmap(x));
Anorm = eigs(RRtmap,m,1,'LA',eigsopt);

%% Algorithm

prob.A = A;
prob.b = b;
prob.lam = lambda;
prob.q = q;
prob.m = m;
prob.n = n;
prob.floss = Leastsquare_Loss();

options.x0 = zeros(n,1);
options.tol = 1.0e-3;
options.iter_print = 0;
options.result_print = 1;
options.Ini_step = 1;
options.maxiter = 50000;
options.r = 4;
options.Anorm = Anorm;

[out] = HpgSRN_main(prob,options); 