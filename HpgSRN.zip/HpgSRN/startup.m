Home = pwd;
addpath(genpath(Home));